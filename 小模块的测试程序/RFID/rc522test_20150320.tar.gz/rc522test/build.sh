arm-none-linux-gnueabi-gcc -o spidev_test spidev_test.c -static
